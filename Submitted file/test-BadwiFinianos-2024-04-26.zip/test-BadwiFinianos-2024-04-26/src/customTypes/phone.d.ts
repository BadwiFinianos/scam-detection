export interface Phone {
  value: string;
}