export interface RuleResponse {
  ruleName: string;
  isValid: boolean;
}
