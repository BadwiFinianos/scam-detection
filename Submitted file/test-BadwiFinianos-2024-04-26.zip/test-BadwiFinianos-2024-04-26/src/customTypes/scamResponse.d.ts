export interface ScamResponse {
  reference: string;
  scam: boolean;
  rules: string[];
}
