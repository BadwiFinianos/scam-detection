export interface Vehicle {
  make: string;
  model: string;
  version: string;
  category: string;
  registerNumber: string;
  mileage: number;
}
