import { Phone } from "@customTypes/index";

export interface Contacts {
  firstName: string;
  lastName: string;
  email: string;
  phone: Phone;
}