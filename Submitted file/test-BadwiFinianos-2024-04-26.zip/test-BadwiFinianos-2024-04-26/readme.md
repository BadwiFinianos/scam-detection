To run the code: npm run start
To run the test: npm run test



PS: I didn't manage my time correctly so i couldn't finish all the tests and documentations

Thank you